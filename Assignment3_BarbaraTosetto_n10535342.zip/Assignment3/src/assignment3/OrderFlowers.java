package assignment3;


import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author barbaratosetto
 */
public class OrderFlowers { 
    
    private int quantity;
    private AnnualFlowers annualFlowers;
    private static final int MAX_ORDERS = 10;
    private static final int  NUM_FLOWERS = 4;
    private AnnualFlowers[] orders;
    private int numOrders;
    private int[][] orderQty;
    
    
    public OrderFlowers() {
        orders = new AnnualFlowers[MAX_ORDERS];
        orderQty = new int[MAX_ORDERS][NUM_FLOWERS];
        numOrders = 0;
    }
    
    public void userInput(){
        Scanner scan = new Scanner(System.in);
        String customerInput;
       
        do{
            System.out.println("Type your order as number of stems of each kind."
                    + "Ty exit to stop the order.");
            customerInput = scan.nextLine();
            if(!customerInput.equals("exit")){
                String[] information = customerInput.split(",");
                int[] quantity = new int[NUM_FLOWERS];
                for(int i = 0; i < NUM_FLOWERS; i++){
                    if(i < information.length){
                        quantity[i] = Integer.parseInt(information[i]);
                    } else {
                        quantity[i] = 0;
                    }
                }
            }
            orders[numOrders] = new AnnualFlowers(quantity);
            //orderQty[numOrders] [orders]= quantity;
            numOrders++;
            
        }while (!customerInput.equals("exit") && numOrders < MAX_ORDERS);
        
    }
    
    public double totalOrder(int column){
        return MyUtilityClass.getTotal(orderQty, column);
    }
    
    @Override
    public String toString() {
        String result = "";
        System.out.println(MyUtilityClass.flowerArray2D(AnnualFlowers));
        
        for (int i = 0; i < AnnualFlowers.NUM_FLOWERS; i++) {
            int total = getTotal(i);
            result += String.format(AnnualFlowers[i], total);
        }
        
        return result;
                
    }  

}
