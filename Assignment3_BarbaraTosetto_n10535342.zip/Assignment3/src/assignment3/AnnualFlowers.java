package assignment3;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author barbaratosetto
 */
public class AnnualFlowers {

    private final String[][] flowersArray = {{"Marigold", "2.3"},
                                             {"Pansy", "1.50"},
                                             {"Zinnias", "5.12"},
                                             {"Petunia", "3.25"}
    };
    //private String flower;
    private int quantity;
    
    public AnnualFlowers(int qty) {
        this. quantity = qy;
    }
    
    public int getQuantity(){
        return quantity;
    }
    
    public void setQuantity(int qty){
        this. quantity = qty;
    }
    
//    public String getFlower(){
//        return flower;
//    }
//    
//    public void setFlower(String flowerName){
//        this.flower = flowerName;
//    }
    
    public String[] getFlowersNames(){
        String[] flowersNames = new String[flowersArray.length];
        for (int i = 0; i < flowersArray.length; i++){
            flowersNames[i] = flowersArray[i][0];
        }
        return flowersNames;
    }
    
    public double flowerTotalPrice(){
        double[] flowerPrice = new double[flowersArray.length];
        for(int i = 0; i < flowersArray .length; i++){
            flowerPrice[i] = Double.parseDouble(flowersArray[i][1]);
        }
        
        return flowerPrice;
    }
    
     @Override
    public String toString() {
        String result = "";
        
        for (int i = 0; i < flowersArray.length; i++){
            result += ("**Combined Order** \n" 
                 + MyUtilityClass.getTotal();
        }
         return result;
        
    }
    
}
